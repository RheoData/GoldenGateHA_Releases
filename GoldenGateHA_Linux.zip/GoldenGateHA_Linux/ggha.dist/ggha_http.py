#!/usr/bin python3
# Copyright (c) 2023 RheoData and/or its affiliates.  All rights reserved.
#
# Since:        November 2023
# Author:       Bobby Curtis <bobby.curtis@rheodata.com>
# Description:  RheoData GoldenGateHA
#
# DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
#
import sys
import tornado.ioloop
import tornado.web


class MainHandler(tornado.web.RequestHandler):
    def get(self):
        self.render("./html/index.html")

#class gghaHandler(tornado.web.RequestHandler):
#    def get(self):
#        self.render("../html/ggha.html")

application = tornado.web.Application([
    (r"/", MainHandler),
    #(r"/ggha", gghaHandler),
    (r"/images/(.*)", tornado.web.StaticFileHandler, {
        "path": "./images/"
    })
])

def http_main():
    application.listen(8001, '0.0.0.0')
    #print("Listening on 8001")
    tornado.ioloop.IOLoop.instance().start()

if __name__ == "__main__":
    http_main()